-- Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare 
-- l’univocità dei valori di ciascuna PK (una query per tabella implementata).

Select ProductID, Count(*)
From Product
Group By ProductID
Having Count(*) > 1;

Select CategoryID, Count(*)
From Category
Group By CategoryID
Having Count(*) > 1;

Select StateID, Count(*)
From State
Group By StateID
Having Count(*) > 1;

Select RegionID, Count(*)
From Region
Group By RegionID
Having Count(*) > 1;

Select SalesOrderID, Count(*)
From Sales
Group By SalesOrderID
Having Count(*) > 1;

-- 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
-- la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base 
-- alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT s.SalesOrderID
, s.OrderDate
, p.ProductName
, c.CategoryName
, st.StateName
, r.RegionName
, CASE 
	WHEN DATEDIFF(CurDate(), s.OrderDate) > 180 THEN "True"
    WHEN DATEDIFF(CurDate(), s.OrderDate) <= 180 THEN "False"
  END AS Flag
FROM sales as s
LEFT JOIN region as r
ON s.RegionID = r.RegionID
LEFT JOIN state as st
ON r.StateID = st.StateID
LEFT JOIN product as p
ON s.ProductID = p.ProductID
LEFT JOIN category as c
ON p.CategoryID = c.CategoryID;

-- 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle
-- vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e 
-- non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.

SELECT ProductID
, Quantity
FROM sales
WHERE Quantity > (SELECT avg(Quantity)
				  FROM sales
                  WHERE YEAR(OrderDate) = (SELECT MAX(YEAR(OrderDate)) 
										   FROM sales))
AND
Year(OrderDate) = (SELECT MAX(YEAR(OrderDate))
					from sales)
ORDER BY ProductID ASC;

-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT Year(s.OrderDate) as Annualità
, p.ProductID
, p.ProductName
, SUM(s.LineTotal) as Fatturato_totale
FROM sales as s
LEFT JOIN product as p
ON s.ProductID = p.ProductID
GROUP BY Year(s.OrderDate), p.ProductID, p.ProductName;

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT YEAR(s.OrderDate) AS Annualità
, st.StateName
, SUM(s.LineTotal) AS Fatturato_Totale
FROM sales AS s
LEFT JOIN Region AS r
ON s.RegionID = r.RegionID
LEFT JOIN State AS st
ON r.StateID = st.StateID
GROUP BY YEAR(s.OrderDate), st.StateName
ORDER BY YEAR(s.OrderDate) ASC, SUM(s.LineTotal) ASC;

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
                                                   
SELECT c.CategoryID
, c.CategoryName
, sum(s.LineTotal) AS Fatturato_Totale
FROM sales AS s
LEFT JOIN product as p
ON s.ProductID = p.ProductID
LEFT JOIN category as c
ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryID, c.CategoryID
ORDER BY Fatturato_Totale DESC;

-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT p.ProductID
, p.ProductName
FROM product as p
LEFT JOIN sales as s
ON p.ProductID = s.ProductID
WHERE s.LineTotal IS NULL;

SELECT p.ProductID
, p.ProductName
FROM product p
WHERE NOT EXISTS (
        SELECT 1
        FROM sales s
        WHERE s.ProductID = p.ProductID);

-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
-- (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW Products_Info AS
( 
SELECT p.ProductID
, p.ProductName
, c.CategoryName
FROM product as p
LEFT JOIN category as c
ON p.CategoryID = c.CategoryID
);

SELECT *
FROM Products_Info;

-- 9)	Creare una vista per le informazioni geografiche

CREATE VIEW Geographic_Info AS
( 
SELECT s.StateId
, s.StateName
, r.RegionID
, r.RegionName
FROM region as r
LEFT JOIN state as s
ON r.StateID = s.StateID
);

SELECT *
FROM Geographic_Info;
