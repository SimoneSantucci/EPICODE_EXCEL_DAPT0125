CREATE DATABASE ToysGroup;

USE ToysGroup;

CREATE TABLE Category(
CategoryID int not null,
CategoryName Varchar (30),
constraint PK_CategoryID Primary Key (CategoryID));

CREATE TABLE State(
StateID int not null,
StateName Varchar (30),
constraint PK_StateID Primary Key (StateID));

CREATE TABLE Product(
ProductID int not null,
ProductName Varchar (30),
CategoryID int,
ListPrice Decimal (10,2),
constraint PK_ProductID Primary Key (ProductID),
constraint FK_CategoryID Foreign Key (CategoryID) references Category (CategoryID));

CREATE TABLE Region(
RegionID int not null,
RegionName Varchar (30),
StateID int,
constraint PK_RegionID Primary Key (RegionID),
constraint FK_StateID Foreign Key (StateID) references State (StateID));

CREATE TABLE Sales(
SalesOrderID int not null,
OrderDate date,
RegionID int,
ProductID int,
Quantity int,
UnitPrice Decimal (10,2),
LineTotal Decimal (10,2),
constraint PK_SalesOrderID Primary Key (SalesOrderID),
constraint FK_RegionID Foreign Key (RegionID) references Region (RegionID),
constraint FK_ProductID Foreign Key (ProductID) references Product (ProductID));
